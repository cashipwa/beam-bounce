﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controller : MonoBehaviour {

	public List<GameObject> allThreats = new List<GameObject>();

	// Use this for initialization
	void Start () {
		Threat[] allThreatScripts = FindObjectsOfType<Threat> ();
		foreach (Threat threat in allThreatScripts) {
			allThreats.Add (threat.gameObject);
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
