﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pulse : MonoBehaviour {

	[SerializeField] private float laserPos = .625f;
	public float speed = 1;

	private LightBeam laser;

	public GameObject pulsePrefabRef;

	// Use this for initialization
	void Start () {
		transform.localPosition = new Vector3 (laserPos, 0, 0);
		laser = transform.parent.GetComponent<LightBeam> ();

		Color newColor = laser.GetComponent<LineRenderer> ().startColor;

		ParticleSystem.MainModule main = GetComponent<ParticleSystem> ().main;
		main.startColor = newColor;

		ParticleSystem.ColorOverLifetimeModule col = GetComponent<ParticleSystem> ().colorOverLifetime;
		Gradient grad = new Gradient ();
		grad.SetKeys ( new GradientColorKey[] { new GradientColorKey(newColor, 0.0f), new GradientColorKey(newColor, 1.0f) }, new GradientAlphaKey[] { new GradientAlphaKey(1.0f, 0.0f), new GradientAlphaKey(0.0f, 1.0f) });
		col.color = grad;
	}
	
	// Update is called once per frame
	void Update () {
		laserPos += Time.deltaTime * speed;
		//transform.localPosition = new Vector3 (laserPos, 0, 0);

		float distExceed;
		switch(laser.PulseCheckDead (laserPos, out distExceed)) {
		case 0: //Not dead, simply update position.
			transform.position = laser.GetPulsePos (laserPos);
			break;

		case 1: //Dead on this laser, but this laser has children temp lasers. Clone and child all of them to new respective laser parents.
			int numChildren = laser.transform.childCount;
			for (int i = 0; i < numChildren; i++) {
				if (laser.transform.GetChild (i).name == "Temp Laser") {
					GameObject newPulse = Instantiate (pulsePrefabRef, transform.position, Quaternion.identity, laser.transform.GetChild (i));
					newPulse.GetComponent<Pulse> ().laserPos = distExceed;
				}
			}
			Destroy (gameObject);
			break;

		case 2: //Reached the end of all laser paths.
			Destroy (gameObject);
			break;
		}
	}
}
