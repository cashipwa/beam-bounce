﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightBeam : MonoBehaviour {

	public int maxBounces = 3;
	public float rotOffset = 0;
	public bool temp = false;
	public int beamColor = 0;
	private bool refracting = false;

	[SerializeField] private List<Vector3> bouncePoints = new List<Vector3> ();
	[SerializeField] private List<float> bouncePointDistances = new List<float> ();
	private float lastBounceDistance;
	[SerializeField] private float totalDistance;

	private LineRenderer lineRend;

	public GameObject tempLaserPrefab;

	public bool showDebug = false;

	private bool everPrismSplit = false;

	[SerializeField] private bool prismSplit = false;

	// Use this for initialization
	void Awake () {
		lineRend = GetComponent<LineRenderer> ();
	}
	
	// Update is called once per frame
	void Update () {
		bouncePoints.Clear ();
		bouncePointDistances.Clear ();

		bouncePoints.Add (transform.position);
		bouncePointDistances.Add (0);
		lastBounceDistance = 0;

		everPrismSplit = false;
		LaserCast (transform.position, transform.right, maxBounces);

		totalDistance = lastBounceDistance;

		if (!everPrismSplit) {
			int numChildren = transform.childCount;
			for (int i = 0; i < numChildren; i++) {
				if(transform.GetChild(i).name == "Temp Laser")
					Destroy (transform.GetChild (i).gameObject);
			}
			refracting = false;
		}

		lineRend.positionCount = bouncePoints.Count;
		lineRend.SetPositions (bouncePoints.ToArray ());
	}

	void LaserCast (Vector3 origin, Vector3 direction, int bounces) {
		//If bounces have run out, immediately pull out.
		if (maxBounces <= 0)
			return;
		
		//Initialize some empty variables.
		prismSplit = false;
		Ray ray = new Ray (origin, direction);
		RaycastHit hit = new RaycastHit();

		//Raycast and check for collision.
		if (Physics.Raycast (ray, out hit, Mathf.Infinity)) {
			//Raycast hit:
			bouncePoints.Add (hit.point);
			lastBounceDistance += Vector3.Distance (origin, hit.point);
			bouncePointDistances.Add (lastBounceDistance);

			Vector3 newOrigin;
			Vector3 newDirection;

			if (hit.transform.name != null) {
				if (hit.transform.name == "Blocker") {
					return;
				}
				if (hit.transform.tag == "Goal Orb") {
					if (hit.transform.gameObject.GetComponent<GoalOrb> ().color == beamColor)
						hit.transform.gameObject.GetComponent<GoalOrb> ().Illuminate ();
				}
				if (hit.transform.name == "Prism Wall") {
					prismSplit = true;
					everPrismSplit = true;
				}
			}

			if (!prismSplit) {
				//Reflect
				newOrigin = hit.point;
				newDirection = Vector3.Reflect (direction, hit.normal);
				LaserCast (newOrigin, newDirection, bounces - 1);
			}

			else if (prismSplit && !temp) {
				//Refract
				newOrigin = hit.point + (direction.normalized * .01f);
				newDirection = direction;

				if (!refracting) { //Refract first frame
					CreateTempLaser (newOrigin, newDirection, -20, 1, Color.cyan);
					CreateTempLaser (newOrigin, newDirection, 0, 2, Color.magenta);
					CreateTempLaser (newOrigin, newDirection, 20, 3, Color.yellow);
					refracting = true;
				} else { //Refract successive frames
					int numChildren = transform.childCount;
					for (int i = 0; i < numChildren; i++) {
						if (transform.GetChild (i).name == "Temp Laser") {
							transform.GetChild (i).position = newOrigin;
							transform.GetChild (i).rotation = Quaternion.LookRotation (direction, Vector3.forward) * Quaternion.Euler (0, -90 + transform.GetChild (i).GetComponent<LightBeam> ().rotOffset, 0);
						}
					}
				}
			}

			else if (prismSplit && temp) {
				//Pass through
				newOrigin = hit.point + direction * 0.01f;
				newDirection = direction;
				LaserCast (newOrigin, newDirection, bounces - 1);
			}
		} else {
			//Raycast did not hit:
			bouncePoints.Add (origin + (direction * 50));
			lastBounceDistance += 50;
			bouncePointDistances.Add (lastBounceDistance);
		}
	} //End lasercast function.

	public int PulseCheckDead (float pulseDist, out float distExceed) {
		if (pulseDist > totalDistance) {
			distExceed = pulseDist - totalDistance;
			if (refracting) {
				return 1;
			} else {
				return 2;
			}
		} else {
			distExceed = 0;
			return 0;
		}
	}

	public Vector3 GetPulsePos (float pulseDist) {
		int i = 0;
		int j = 0;
		foreach (float dist in bouncePointDistances) {
			if (pulseDist >= dist) {
				j = i;
			}
			i++;
		}

		Vector3 origin = bouncePoints [j];
		float offsetDistance = pulseDist - bouncePointDistances [j];
		Vector3 offsetDirection = Vector3.Normalize (bouncePoints [j + 1] - bouncePoints [j]);
		Vector3 finalPos = origin + (offsetDirection * offsetDistance);

		return finalPos;
	}

	void CreateTempLaser(Vector3 origin, Vector3 direction, float newRotOffset, int beamColorID, Color color) {
		Quaternion rot = Quaternion.LookRotation (direction, Vector3.forward) * Quaternion.Euler(0, -90 + rotOffset, 0);
		GameObject laser = Instantiate (tempLaserPrefab, origin, rot, transform);
		laser.name = "Temp Laser";
		laser.GetComponent<LightBeam> ().rotOffset = newRotOffset;
		laser.GetComponent<LightBeam> ().beamColor = beamColorID;
		laser.GetComponent<LightBeam> ().temp = true;
		laser.GetComponent<LineRenderer> ().startColor = color;
		laser.GetComponent<LineRenderer> ().endColor = color;
	}
}
