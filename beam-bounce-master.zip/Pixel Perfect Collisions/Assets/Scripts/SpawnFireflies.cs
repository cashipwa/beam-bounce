﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnFireflies : MonoBehaviour {

	public GameObject fireflyPrefab;

	public float spawnInterval = 1;
	private float spawnIntervalTimer = 0;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		spawnIntervalTimer += Time.deltaTime;
		if (spawnIntervalTimer >= spawnInterval) {
			spawnIntervalTimer -= spawnInterval;
			Instantiate (fireflyPrefab);
		}
	}
}
