﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Snapper : MonoBehaviour {

	public float percentageToSnap = .5f;
	public List<string> all = new List<string> ();

	// Use this for initialization
	void Start () {
		Shuffle (all);
		int length = all.Count;
		int numSnapped = 0;
		while ((numSnapped / percentageToSnap) < length) {
			numSnapped++;
			Debug.LogFormat("{0} snapped.", all [0]);
			all.RemoveAt (0);
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void Shuffle (List<string> list) {
		int n = list.Count;
		while(n > 1) {
			n--;
			int k = Random.Range(0, n + 1);
			string value = list[k];
			list[k] = list[n];
			list[n] = value;
		}
	}
}
