﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class SendPulse : MonoBehaviour {

	private AudioSource aud;
	private Transform laser;

	[Range(.25f, 2f)] public float interval = 1;
	private float intervalTimer = 0;

	public GameObject pulsePrefabRef;

	// Use this for initialization
	void Start () {
		aud = GetComponent<AudioSource> ();
		laser = GameObject.Find ("Laser").transform;
	}
	
	// Update is called once per frame
	void Update () {
		intervalTimer += Time.deltaTime;
		if (intervalTimer >= interval) {
			intervalTimer -= interval;
			Interval ();
		}
	}

	void Interval () {
		//aud.Play ();
		Instantiate (pulsePrefabRef, laser.position, Quaternion.identity, laser);
	}
}
