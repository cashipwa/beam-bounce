﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MulticolorDirectionalSpray : MonoBehaviour {

	private ParticleSystem ps;
	private ParticleSystem.MainModule main;

	public Color[] colors;
	private int colorsLength;

	// Use this for initialization
	void Start () {
		ps = GetComponent<ParticleSystem> ();
		main = ps.main;
		colorsLength = colors.Length;
	}
	
	// Update is called once per frame
	void Update () {
		main.startColor = colors[Random.Range(0, colorsLength)];
		}
	}
