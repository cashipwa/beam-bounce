﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OrbManager : MonoBehaviour {

	private List<GoalOrb> goalOrbs = new List<GoalOrb>();

	public int litup = 0;
	private int prevLitup = 0;

	private AudioSource aud;
	public AudioClip[] audioClips;

	// Use this for initialization
	void Start () {
		foreach (GameObject obj in GameObject.FindGameObjectsWithTag("Goal Orb")) {
			goalOrbs.Add (obj.GetComponent<GoalOrb> ());
			aud = GetComponent<AudioSource> ();
		}
	}
	
	// Update is called once per frame
	void Update () {
		litup = 0;
		foreach (GoalOrb goalOrb in goalOrbs) {
			if (goalOrb.illuminated)
				litup++;
		}

		if (litup > prevLitup) {
			aud.PlayOneShot (audioClips [0]);
			if (litup == goalOrbs.Count)
				aud.PlayOneShot (audioClips [2]);
		}
		if (litup < prevLitup) {
			aud.PlayOneShot (audioClips [1]);
		}

		prevLitup = litup;
	}
}
