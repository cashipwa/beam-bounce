﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathTimer : MonoBehaviour {

	public float lifespan = .25f;
	private float age = 0;
	
	// Update is called once per frame
	void Update () {
		age += Time.deltaTime;
		if (age >= lifespan)
			Destroy (gameObject);
	}
}
