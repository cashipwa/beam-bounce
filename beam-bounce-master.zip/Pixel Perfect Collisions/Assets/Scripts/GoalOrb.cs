﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoalOrb : MonoBehaviour {

	public int color = 0;

	public bool illuminated = false;
	private float illuminateFadeTime = .1f;
	private float illuminateFadeTimeTimer = 0;

	public Material illuminatedMaterialRef;
	public Material unilluminatedMaterialRef;

	private ParticleSystem aura;

	private Renderer rend;
	private AudioSource aud;

	private Color fullColor;

	// Use this for initialization
	void Awake () {
		rend = GetComponent<Renderer> ();
		aud = GetComponent<AudioSource> ();
		aud.volume = 0;

		fullColor = new Color (255, 255, 255, 255);

		aura = transform.GetChild (0).GetComponent<ParticleSystem> ();
	}

	void LateUpdate () {
		if (illuminated) {
			//rend.material = illuminatedMaterialRef;
			aud.volume = .25f;
			var emission = aura.emission;
			emission.rateOverTime = 50f;
		} else {
			//rend.material = unilluminatedMaterialRef;
			aud.volume = 0;
			var emission = aura.emission;
			emission.rateOverTime = 0;
		}

		illuminateFadeTimeTimer += Time.deltaTime;
		if(illuminateFadeTimeTimer > illuminateFadeTime)
			illuminated = false;
	}

	public void Illuminate () {
		illuminated = true;
		illuminateFadeTimeTimer = 0;
	}
}
