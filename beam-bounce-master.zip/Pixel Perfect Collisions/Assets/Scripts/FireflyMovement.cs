﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireflyMovement : MonoBehaviour {

	private Controller controller;

	public float moveSpeed = 1;
	public Vector3 moveDir = new Vector3 (1, 0, 0);
	private Vector3 moveDirTransfer = new Vector3 (1, 0, 0);

	private Vector3 direction = Vector3.zero;

	public float dirChangeInterval = 1;
	private float dirChangeIntervalTimer = 0;
	public float dirChangeDuration = 1;
	private float dirChangeDurationTimer = 0;

	public float awareRadius = 3f;
	public float flightRadius = .5f;

	private float jostleDistance = .01f;

	private float thinkInterval = 1;
	private float thinkIntervalTimer = 0;

	// Use this for initialization
	void Start () {
		controller = GameObject.Find ("Controller").GetComponent<Controller> ();
		//moveDir = GenerateDirection ();
	}
	
	// Update is called once per frame
	void Update () {
		//Wander ();
		if (thinkIntervalTimer == 0) {
			FindThreats (out direction);
			thinkIntervalTimer = thinkInterval - 1;
		} else {
			thinkIntervalTimer--;
		}

		transform.Translate (direction * moveSpeed * Time.deltaTime);
	}

	void Wander () {
		transform.Translate (moveDir * moveSpeed);

		dirChangeIntervalTimer += Time.deltaTime;
		if (dirChangeIntervalTimer >= dirChangeInterval) {
			dirChangeIntervalTimer -= dirChangeInterval;

			Vector3 targetMoveDir = GenerateDirection ();
			Vector3 moveDirDifference = targetMoveDir - moveDir;
			moveDirTransfer = moveDirDifference / dirChangeDuration;

			dirChangeDurationTimer = dirChangeDuration;
		}

		if (dirChangeDurationTimer > 0) {
			moveDir += moveDirTransfer * Time.deltaTime;

			dirChangeDurationTimer -= Time.deltaTime;
			if (dirChangeDurationTimer < 0)
				dirChangeDurationTimer = 0;
		}
	}

	void FindThreats (out Vector3 optimalEscapeAngle) {
		optimalEscapeAngle = Vector3.zero;

		//Initialize some arrays.

		/*
		GameObject[] threats = GameObject.FindGameObjectsWithTag("Threat");
		List<GameObject> threatsList = new List<GameObject>();
		foreach (GameObject threat in threats) {
			if(threat != gameObject) {
				if (Vector3.Distance (transform.position, threat.transform.position) <= (awareRadius * threat.GetComponent<Threat>().radiusMultiplier)) {
					threatsList.Add (threat);
				}
			}
		}
		threats = threatsList.ToArray ();
		*/

		GameObject[] threats;
		List<GameObject> threatsList = new List<GameObject>(controller.allThreats);
		List<GameObject> revisedThreatsList = new List<GameObject> ();
		foreach (GameObject threat in threatsList) {
			if(threat != gameObject) {
				if (Vector3.Distance (transform.position, threat.transform.position) <= (awareRadius * threat.GetComponent<Threat>().radiusMultiplier)) {
					revisedThreatsList.Add (threat);
				}
			}
		}
		threats = revisedThreatsList.ToArray ();

		int count = threats.Length;
		//Debug.Log (count);

		Vector3[] threatOffsets = new Vector3[count];
		float[] threatDistances = new float[count];
		Vector3[] threatAngles = new Vector3[count];
		Vector3[] escapeAngles = new Vector3[count];
		float[] threatWeights = new float[count];
		float[] threatWeightMultipliers = new float[count];
		float[] threatRadiusMultipliers = new float[count];
		Vector3[] weightedEscapeAngles = new Vector3[count];

		bool goOn = count > 0;
		while (goOn) {
			float escapeXSum = 0;
			float escapeYSum = 0;

			for (int i = 0; i < count; i++) {
				threatOffsets [i] = threats [i].transform.position - transform.position;
				threatDistances [i] = Vector3.Distance (Vector3.zero, threatOffsets [i]);
				threatAngles [i] = threatOffsets [i] / threatDistances [i];
				escapeAngles [i] = threatAngles [i] * -1;

				threatWeightMultipliers [i] = threats [i].GetComponent<Threat> ().weightMultiplier;
				threatRadiusMultipliers [i] = threats [i].GetComponent<Threat> ().radiusMultiplier;

				float distance = Vector3.Distance (transform.position, threats [i].transform.position);
				if (distance < (flightRadius * threatRadiusMultipliers[i]))
					threatWeights [i] = 1;
				else {
					float range = (awareRadius * threatRadiusMultipliers[i]) - (flightRadius * threatRadiusMultipliers[i]);
					float distanceAlongRange = distance - (flightRadius * threatRadiusMultipliers[i]);
					threatWeights [i] = 1 - (distanceAlongRange / range);
				}

				weightedEscapeAngles [i] = escapeAngles [i] * threatWeights [i];
				escapeXSum += weightedEscapeAngles [i].x;
				escapeYSum += weightedEscapeAngles [i].y;

				Debug.DrawLine (transform.position, threats [i].transform.position, (Color.red * threatWeights [i]) + (Color.green * (1 - threatWeights [i])));
				DebugDrawPoint (transform.position + (weightedEscapeAngles [i] * 1), Color.white);
				Debug.DrawLine (transform.position, transform.position + (weightedEscapeAngles [i] * 1), Color.white);
			}
			
			optimalEscapeAngle = new Vector3 (escapeXSum / count, escapeYSum / count, 0);
			if (optimalEscapeAngle != Vector3.zero) { 
				goOn = false;
				optimalEscapeAngle /= Vector3.Distance (Vector3.zero, optimalEscapeAngle);
				DebugDrawPoint (transform.position + (optimalEscapeAngle * 2), Color.cyan);
				Debug.DrawLine (transform.position, transform.position + (optimalEscapeAngle * 2), Color.cyan);
			} else {
				Vector3 jostle = new Vector3 (Random.Range (jostleDistance * -1, jostleDistance), Random.Range (jostleDistance * -1, jostleDistance), 0);
				transform.Translate (jostle);
			}
		}
	}

	Vector3 GenerateDirection() {
		Vector3 genMoveDir = new Vector3 (0, 0, 0);

		genMoveDir.x = Random.Range (0f, 1f);
		genMoveDir.y = 1 - moveDir.x;

		if (CoinFlip ())
			genMoveDir.x *= -1;
		if (CoinFlip ())
			genMoveDir.y *= -1;

		return genMoveDir;
	}

	bool CoinFlip() {
		if (Random.Range (0, 2) == 1) {
			return true;
		}
		else {
			return false;
		}
	}

	void DebugDrawPoint(Vector3 point, Color col) {
		float offset = .1f;
		Debug.DrawLine (point + (Vector3.up * offset), point - (Vector3.up * offset), col);
		Debug.DrawLine (point + (Vector3.right * offset), point - (Vector3.right * offset), col);
	}
}
