﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CursorStatus : MonoBehaviour {

	public int id = 0;
	public float timeSinceMsg = 0;
	public float timeout = 1;

	// Use this for initialization
	void Start () {
		SpriteRenderer rend = GetComponent<SpriteRenderer> (); 
		rend.color = Color.HSVToRGB (Random.Range (0f, 1f), .25f, 1);
	}

	// Update is called once per frame
	void Update () {
		timeSinceMsg += Time.deltaTime;
		if (timeSinceMsg > timeout) {
			Destroy (gameObject);
		}
	}
}
