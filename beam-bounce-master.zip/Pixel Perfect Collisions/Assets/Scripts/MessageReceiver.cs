﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MessageReceiver : MonoBehaviour {

	[Header("References")]
	public OscIn oscIn;
	public GameObject cursorPrefab;
	public GameObject childPrefab;

	[Header("Instances")]
	public GameObject[] cursors;

	[Header("Smoothing")]
	public bool smoothing = true;
	public float smoothTranSpeed = 10;
	public float smoothRotSpeed = 5;

	public float smoothTranCloseEnough = .125f;
	public float smoothRotCloseEnough = 2;

	[Header("Calibration")]
	public float moveXMultiplier = 1;
	public float moveYMultiplier = 1;
	public float xOffset = 0;
	public float yOffset = 0;
	[Range(80, 100)] public float angleOffset = 0;

	private Vector3 lastPos;
	private float lastRot;

	// Use this for initialization
	void Start () {
		oscIn.Open (57120);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnEnable() {
		oscIn.Map ("/blob", BlobUpdate);
	}

	void OnDisable () {
		oscIn.Unmap (BlobUpdate);
	}

	void BlobUpdate( OscMessage message) {
		//Initialize some variables.
		float blobID, posX, posY, blobAngle;
		//Try to unpack the message. This shouldn't really ever... fail, I reckon.
		if (message.TryGet (0, out blobID) && message.TryGet (1, out posX) && message.TryGet (2, out posY) && message.TryGet (9, out blobAngle)) {
			//Little debug message.
			//Debug.Log ("Blob ID: " + blobID + " // X: " + posX + " // Y: " + posY + " // Angle: " + blobAngle);

			//Convert posX and posY into more "usable" values.
			//Substract .5 from each value to change the span from (0 -- 1) to (-.5 -- .5).
			//Also multiply by the calibration multiplier values and add offset values.
			posX = ((posX - .5f) * moveXMultiplier) + xOffset;
			posY = ((posY - .5f) * moveYMultiplier) + yOffset;

			//Covnert blobAngle into a more "usable" value.
			//Add the calibration offset value.
			//If it's over 360 or below 0, get it back within the span.
			blobAngle += angleOffset;
			if (blobAngle >= 360)
				blobAngle -= 360;
			else if (blobAngle < 0)
				blobAngle += 360;

			//Get all cursors.
			cursors = GameObject.FindGameObjectsWithTag ("OSC Cursor");

			GameObject myCursor = null;
			//Check if the cursor this message is about already exists -- if so, assign myCursor to be that cursor and update its lifespan timer.
			foreach (GameObject cursor in cursors) {
				if (cursor.GetComponent<CursorStatus> ().id == blobID) {
					myCursor = cursor;
					myCursor.GetComponent<CursorStatus> ().timeSinceMsg = 0;
				}
			}

			//If it wasn't in the list of cursors, it doesn't exist yet, which means it's a new blob.
			//Instantiate it.
			if (myCursor == null) {
				myCursor = Instantiate (cursorPrefab);
				myCursor.name = "OSC Cursor " + blobID;
				myCursor.GetComponent<CursorStatus> ().id = (int)blobID;

				//If childPrefab has been set, give it a child.
				if (childPrefab != null)
					Instantiate (childPrefab, myCursor.transform);
			}

			//Now, regardless of whether myCursor has already existed or it's just been created, it exists.
			//So, time to set its position and rotation.
			if (smoothing && lastPos != null) { //If both smoothing is on AND this cursor has existed for more than one frame, use smoothing rules.

				//Translation.
				if (Vector3.Distance (lastPos, new Vector3(posX, posY, -1)) > smoothTranCloseEnough) {
					Debug.Log ("Smooth");
					float distanceBetween = Vector3.Distance (myCursor.transform.position, new Vector3 (posX, posY, -1));
					myCursor.transform.position = Vector3.MoveTowards (myCursor.transform.position, new Vector3 (posX, posY, -1), distanceBetween * Time.deltaTime * smoothTranSpeed);
					//myCursor.transform.position = new Vector3 (posX, posY, -1);
				}
				
				//Rotation.
				if (Mathf.Abs(CalculateEulerDifference (lastRot, blobAngle)) > smoothRotCloseEnough) {
					float stepRotation = CalculateEulerDifference (myCursor.transform.eulerAngles.z, blobAngle);
					myCursor.transform.Rotate(new Vector3 (0, 0, stepRotation * Time.deltaTime * smoothRotSpeed));
					//myCursor.transform.eulerAngles = new Vector3 (0, 0, blobAngle);
				}
			} else { //If smoothing is off, or this is the first frame this cursor has existed, just set its position and rotation directly to the incoming values.
				myCursor.transform.position = new Vector3 (posX, posY, -1);
				myCursor.transform.eulerAngles = new Vector3 (0, 0, blobAngle);
			}
			lastPos = myCursor.transform.position;
			lastRot = myCursor.transform.eulerAngles.z;
			//lastPos = new Vector3 (posX, posY, -1);
			//lastRot = blobAngle;
		}
		//End of BlobUpdate.
	}

	private float CalculateEulerDifference(float currentRotation, float targetRotation) {
		if (currentRotation == targetRotation) {
			return targetRotation;
		}

		bool targetGreater = currentRotation < targetRotation;
		float increaseAngle;
		float decreaseAngle;

		if (targetGreater) {
			increaseAngle = targetRotation - currentRotation;
			decreaseAngle = currentRotation + (360 - targetRotation);
		} else {
			increaseAngle = (360 - currentRotation) + targetRotation;
			decreaseAngle = currentRotation - targetRotation;
		}

		float difference;
		if (increaseAngle <= decreaseAngle) {
			difference = increaseAngle;
		} else {
			difference = decreaseAngle * -1;
		}

		return difference;
	}
}
